// javascript 
let buttons = document.querySelector(".buttons");
let btn = document.querySelectorAll("span");
let value_ofcalc = document.getElementById("value_ofcalc");
let darkmode = document.querySelector(".darkmode");
let body = document.querySelector("body");

for (let i = 0; i < btn.length; i++) {
  btn[i].addEventListener("click", function () {
    if (this.innerHTML == "=") {
      value_ofcalc.innerHTML = eval(value_ofcalc.innerHTML);
      value_ofcalc.style.opacity = "1";
      value_ofcalc.style.transform = "translateY(0)";
    } else {
      if (this.innerHTML == "Clear") {
        value_ofcalc.innerHTML = "";
      } else {
        value_ofcalc.innerHTML += this.innerHTML;
      }
    }
  });
}
// darkmode
darkmode.onclick = function () {
  body.classList.toggle("dark");
};
